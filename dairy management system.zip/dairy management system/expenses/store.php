<?php

require '../config/database.php';

$sql = "
INSERT INTO expenses(
category,
amount,
description,
expense_date
)
VALUES(
?,?,?,?
)
";

$stmt = $pdo->prepare($sql);

$stmt->execute([

$_POST['category'],
$_POST['amount'],
$_POST['description'],
$_POST['expense_date']

]);

header("Location:index.php");
exit();