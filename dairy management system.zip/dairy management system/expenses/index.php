<?php

require '../includes/auth.php';

if(
    $_SESSION['role']!='admin' &&
    $_SESSION['role']!='accountant'
){
    die("Access Denied");
}
require '../config/database.php';

$totalExpenses = $pdo->query("
SELECT COALESCE(
SUM(amount),
0
)
FROM expenses
")->fetchColumn();

$todayExpenses = $pdo->query("
SELECT COALESCE(
SUM(amount),
0
)
FROM expenses
WHERE expense_date = CURDATE()
")->fetchColumn();

$totalRecords = $pdo->query("
SELECT COUNT(*)
FROM expenses
")->fetchColumn();

$expenses = $pdo->query("
SELECT *
FROM expenses
ORDER BY expense_date DESC
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">
    <div class="row mb-4">

<div class="col-md-4">

<div class="card bg-danger text-white">

<div class="card-body">

<h6>Today's Expenses</h6>

<h2>
KES <?= number_format($todayExpenses) ?>
</h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-dark text-white">

<div class="card-body">

<h6>Total Expenses</h6>

<h2>
KES <?= number_format($totalExpenses) ?>
</h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-secondary text-white">

<div class="card-body">

<h6>Total Records</h6>

<h2>
<?= $totalRecords ?>
</h2>

</div>

</div>

</div>

</div>

<div class="d-flex justify-content-between">

<h2>Expenses</h2>

<a href="create.php"
class="btn btn-danger">

Add Expense

</a>

</div>

<br>

<table class="table table-bordered">

<thead>

<tr>

<th>Date</th>
<th>Category</th>
<th>Description</th>
<th>Amount</th>
<th>Actions</th>
</tr>

</thead>

<tbody>

<?php foreach($expenses as $expense): ?>

<tr>

<td><?= $expense['expense_date'] ?></td>

<td><?= $expense['category'] ?></td>

<td><?= $expense['description'] ?></td>

<td>
KES
<?= number_format($expense['amount'],2) ?>
</td>
<td>

<a href="edit.php?id=<?= $expense['id'] ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $expense['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this expense?')">

Delete

</a>

</td>
</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>