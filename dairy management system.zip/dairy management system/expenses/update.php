<?php

require '../config/database.php';

$stmt = $pdo->prepare("
UPDATE expenses
SET
category=?,
description=?,
amount=?
WHERE id=?
");

$stmt->execute([

$_POST['category'],
$_POST['description'],
$_POST['amount'],
$_POST['id']

]);

header("Location:index.php");
exit();