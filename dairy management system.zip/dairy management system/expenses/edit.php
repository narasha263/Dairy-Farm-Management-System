<?php

require '../includes/auth.php';
require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
SELECT *
FROM expenses
WHERE id=?
");

$stmt->execute([$id]);

$expense = $stmt->fetch();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Edit Expense</h2>

<form action="update.php" method="POST">

<input type="hidden"
name="id"
value="<?= $expense['id']; ?>">

<div class="mb-3">

<label>Category</label>

<input type="text"
name="category"
value="<?= $expense['category']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Description</label>

<textarea name="description"
class="form-control"><?= $expense['description']; ?></textarea>

</div>

<div class="mb-3">

<label>Amount</label>

<input type="number"
step="0.01"
name="amount"
value="<?= $expense['amount']; ?>"
class="form-control">

</div>

<button class="btn btn-warning">

Update Expense

</button>

</form>

</div>

</div>