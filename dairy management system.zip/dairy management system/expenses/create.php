<?php

require '../includes/auth.php';

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Add Expense</h2>

<form action="store.php" method="POST">

<div class="mb-3">

<label>Category</label>

<select name="category"
        class="form-control">

<option>Feed</option>
<option>Veterinary</option>
<option>Salaries</option>
<option>Transport</option>
<option>Utilities</option>
<option>Equipment</option>

</select>

</div>

<div class="mb-3">

<label>Amount</label>

<input type="number"
       step="0.01"
       name="amount"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Description</label>

<textarea name="description"
          class="form-control"></textarea>

</div>

<div class="mb-3">

<label>Date</label>

<input type="date"
       name="expense_date"
       value="<?= date('Y-m-d') ?>"
       class="form-control">

</div>

<button class="btn btn-danger">

Save Expense

</button>

</form>

</div>

</div>