<?php

session_start();

require '../config/database.php';

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email = ?";

$stmt = $pdo->prepare($sql);

$stmt->execute([$email]);

$user = $stmt->fetch();

if($user){

    if(password_verify(
        $password,
        $user['password']
    )){

        $_SESSION['user_id'] = $user['id'];

        $_SESSION['fullname'] = $user['fullname'];

        $_SESSION['role'] = $user['role'];

        header("Location: ../dashboard/index.php");
        exit();

    }

}

echo "Invalid Email or Password";