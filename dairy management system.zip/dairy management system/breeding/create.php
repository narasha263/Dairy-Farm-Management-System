<?php

require '../includes/auth.php';
require '../config/database.php';

$cows = $pdo->query("
SELECT *
FROM cows
ORDER BY cow_code
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Add Breeding Record</h2>

<form action="store.php" method="POST">

<div class="mb-3">

<label>Cow</label>

<select name="cow_id" class="form-control" required>

<?php foreach($cows as $cow): ?>

<option value="<?= $cow['id']; ?>">
<?= $cow['cow_code']; ?>
</option>

<?php endforeach; ?>

</select>

</div>

<div class="mb-3">

<label>Service Date</label>

<input type="date"
name="service_date"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Semen Source</label>

<input type="text"
name="semen_source"
class="form-control">

</div>

<div class="mb-3">

<label>Expected Calving Date</label>

<input type="date"
name="expected_calving_date"
class="form-control">

</div>

<div class="mb-3">

<label>Status</label>

<select name="status" class="form-control">

<option value="Pregnant">Pregnant</option>
<option value="Open">Open</option>
<option value="Calved">Calved</option>

</select>

</div>

<button class="btn btn-success">
Save Record
</button>

</form>

</div>

</div>