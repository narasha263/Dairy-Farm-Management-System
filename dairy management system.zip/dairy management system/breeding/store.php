<?php

require '../config/database.php';

$stmt = $pdo->prepare("
INSERT INTO breeding
(
cow_id,
service_date,
semen_source,
expected_calving_date,
status
)
VALUES
(
?,?,?,?,?
)
");

$stmt->execute([

$_POST['cow_id'],
$_POST['service_date'],
$_POST['semen_source'],
$_POST['expected_calving_date'],
$_POST['status']

]);

header("Location:index.php");
exit();