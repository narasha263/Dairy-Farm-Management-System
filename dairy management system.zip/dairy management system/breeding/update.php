<?php

require '../config/database.php';

$stmt = $pdo->prepare("
UPDATE breeding
SET
cow_id=?,
service_date=?,
semen_source=?,
expected_calving_date=?,
status=?
WHERE id=?
");

$stmt->execute([

$_POST['cow_id'],
$_POST['service_date'],
$_POST['semen_source'],
$_POST['expected_calving_date'],
$_POST['status'],
$_POST['id']

]);

header("Location:index.php");
exit();