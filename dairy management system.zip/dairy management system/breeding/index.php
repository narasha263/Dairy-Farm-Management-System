<?php

require '../includes/auth.php';
require '../config/database.php';

$totalBreeding = $pdo->query("
SELECT COUNT(*)
FROM breeding
")->fetchColumn();

$pregnantCows = $pdo->query("
SELECT COUNT(*)
FROM breeding
WHERE status='Pregnant'
")->fetchColumn();

$calvedCows = $pdo->query("
SELECT COUNT(*)
FROM breeding
WHERE status='Calved'
")->fetchColumn();

$sql = "
SELECT
b.*,
c.cow_code

FROM breeding b

JOIN cows c
ON c.id = b.cow_id

ORDER BY b.service_date DESC
";

$records = $pdo->query($sql)->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">
    <div class="row mb-4">

<div class="col-md-4">
<div class="card bg-success text-white">
<div class="card-body">
<h6>Pregnant Cows</h6>
<h2><?= $pregnantCows ?></h2>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card bg-primary text-white">
<div class="card-body">
<h6>Total Breeding Records</h6>
<h2><?= $totalBreeding ?></h2>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card bg-warning text-dark">
<div class="card-body">
<h6>Calved Cows</h6>
<h2><?= $calvedCows ?></h2>
</div>
</div>
</div>

</div>

<div class="d-flex justify-content-between">

<h2>Breeding Records</h2>

<a href="create.php"
class="btn btn-success">

Add Record

</a>

</div>

<br>

<table class="table table-bordered">

<thead>

<tr>

<th>Cow</th>
<th>Service Date</th>
<th>Semen Source</th>
<th>Expected Calving</th>
<th>Status</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php foreach($records as $record): ?>

<tr>

<td><?= $record['cow_code']; ?></td>
<td><?= $record['service_date']; ?></td>
<td><?= $record['semen_source']; ?></td>
<td><?= $record['expected_calving_date']; ?></td>
<td><?= $record['status']; ?></td>

<td>

<a href="edit.php?id=<?= $record['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $record['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete record?')">

Delete

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>