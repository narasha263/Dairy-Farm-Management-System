<?php

require '../includes/auth.php';
require '../config/database.php';

$id = $_GET['id'];


$stmt = $pdo->prepare("
SELECT *
FROM breeding
WHERE id=?
");

$stmt->execute([$id]);

$record = $stmt->fetch();

$cows = $pdo->query("
SELECT *
FROM cows
ORDER BY cow_code
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Edit Breeding Record</h2>

<form action="update.php" method="POST">

<input type="hidden"
name="id"
value="<?= $record['id']; ?>">

<div class="mb-3">

<label>Cow</label>

<select name="cow_id" class="form-control">

<?php foreach($cows as $cow): ?>

<option
value="<?= $cow['id']; ?>"
<?= $cow['id']==$record['cow_id'] ? 'selected' : '' ?>>

<?= $cow['cow_code']; ?>

</option>

<?php endforeach; ?>

</select>

</div>

<div class="mb-3">

<label>Service Date</label>

<input type="date"
name="service_date"
value="<?= $record['service_date']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Semen Source</label>

<input type="text"
name="semen_source"
value="<?= $record['semen_source']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Expected Calving Date</label>

<input type="date"
name="expected_calving_date"
value="<?= $record['expected_calving_date']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Status</label>

<select name="status" class="form-control">

<option value="Pregnant"
<?= $record['status']=='Pregnant' ? 'selected' : '' ?>>
Pregnant
</option>

<option value="Open"
<?= $record['status']=='Open' ? 'selected' : '' ?>>
Open
</option>

<option value="Calved"
<?= $record['status']=='Calved' ? 'selected' : '' ?>>
Calved
</option>

</select>

</div>

<button class="btn btn-warning">
Update Record
</button>

</form>

</div>

</div>