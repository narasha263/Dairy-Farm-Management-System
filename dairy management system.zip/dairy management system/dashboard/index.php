<?php

require '../includes/auth.php';


require '../config/database.php';
$totalCows = $pdo->query("
SELECT COUNT(*) FROM cows
")->fetchColumn();

$healthyCows = $pdo->query("
SELECT COUNT(*)
FROM cows
WHERE status='Healthy'
")->fetchColumn();

$pregnantCows = $pdo->query("
SELECT COUNT(*)
FROM cows
WHERE status='Pregnant'
")->fetchColumn();

$sickCows = $pdo->query("
SELECT COUNT(*)
FROM cows
WHERE status='Sick'
")->fetchColumn();

$milkToday = $pdo->query("
SELECT COALESCE(
SUM(total_milk),
0
)
FROM milk_production
WHERE production_date = CURDATE()
")->fetchColumn();

$chartData = $pdo->query("
SELECT
DATE_FORMAT(production_date,'%b') as month,
SUM(total_milk) as total

FROM milk_production

GROUP BY MONTH(production_date)
")->fetchAll(PDO::FETCH_ASSOC);

$months = [];
$totals = [];

foreach($chartData as $row){

    $months[] = $row['month'];
    $totals[] = $row['total'];

}
$customerCount = $pdo->query("
SELECT COUNT(*)
FROM customers
")->fetchColumn();

$revenueToday = $pdo->query("
SELECT COALESCE(
SUM(total_amount),
0
)
FROM sales
WHERE sale_date = CURDATE()
")->fetchColumn();

$monthlyRevenue = $pdo->query("
SELECT COALESCE(
SUM(total_amount),
0
)
FROM sales

WHERE MONTH(sale_date)=MONTH(CURDATE())
AND YEAR(sale_date)=YEAR(CURDATE())
")->fetchColumn();

$expensesToday = $pdo->query("
SELECT COALESCE(
SUM(amount),
0
)

FROM expenses

WHERE expense_date = CURDATE()
")->fetchColumn();

$monthlyExpenses = $pdo->query("
SELECT COALESCE(
SUM(amount),
0
)

FROM expenses

WHERE MONTH(expense_date)=MONTH(CURDATE())
AND YEAR(expense_date)=YEAR(CURDATE())
")->fetchColumn();

$profitToday =
$revenueToday -
$expensesToday;

$monthlyProfit =
$monthlyRevenue -
$monthlyExpenses;

$totalRevenue = $pdo->query("
SELECT COALESCE(
SUM(total_amount),
0
)
FROM sales
")->fetchColumn();

$totalExpenses = $pdo->query("
SELECT COALESCE(
SUM(amount),
0
)
FROM expenses
")->fetchColumn();

$totalCustomers = $pdo->query("
SELECT COUNT(*)
FROM customers
")->fetchColumn();

$totalProfit = $totalRevenue - $totalExpenses;
$healthCases = $pdo->query("
SELECT COUNT(*)
FROM health_records
")->fetchColumn();

$pregnantCows = $pdo->query("
SELECT COUNT(*)
FROM breeding
WHERE status='Pregnant'
")->fetchColumn();

$vaccinationsDue = $pdo->query("
SELECT COUNT(*)
FROM vaccinations
WHERE next_due_date <= CURDATE()
")->fetchColumn();
?>

<?php include '../includes/header.php'; ?>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content">

    <?php include '../includes/navbar.php'; ?>

    <div class="container-fluid mt-4">

        <?php if($_SESSION['role']=='accountant'): ?>

        <div class="row mb-4">

            <div class="col-md-3">
                <div class="card bg-success text-white shadow">
                    <div class="card-body">
                        <h6>Total Revenue</h6>
                        <h2>KES <?= number_format($totalRevenue) ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-danger text-white shadow">
                    <div class="card-body">
                        <h6>Total Expenses</h6>
                        <h2>KES <?= number_format($totalExpenses) ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-dark text-white shadow">
                    <div class="card-body">
                        <h6>Total Profit</h6>
                        <h2>KES <?= number_format($totalProfit) ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-primary text-white shadow">
                    <div class="card-body">
                        <h6>Customers</h6>
                        <h2><?= $totalCustomers ?></h2>
                    </div>
                </div>
            </div>

        </div>

        <?php endif; ?>

        <h2 class="mb-4">Dashboard</h2>

        <div class="row g-4">

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Total Cows</h6>
                        <h2><?= $totalCows ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Milk Today</h6>
                        <h2><?= $milkToday ?> L</h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Healthy Cows</h6>
                        <h2><?= $healthyCows ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Pregnant Cows</h6>
                        <h2><?= $pregnantCows ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Vaccinations Due</h6>
                        <h2><?= $vaccinationsDue ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Customers</h6>
                        <h2><?= $customerCount ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Revenue Today</h6>
                        <h2>KES <?= number_format($revenueToday,2) ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Expenses Today</h6>
                        <h2>KES <?= number_format($expensesToday,2) ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Profit Today</h6>
                        <h2>KES <?= number_format($profitToday,2) ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow">
                    <div class="card-body">
                        <h6>Monthly Profit</h6>
                        <h2>KES <?= number_format($monthlyProfit,2) ?></h2>
                    </div>
                </div>
            </div>

        </div>

        <div class="card shadow mt-5">

            <div class="card-header">
                <h5>Milk Production Trend</h5>
            </div>

            <div class="card-body">
                <canvas id="milkChart"></canvas>
            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

const ctx = document.getElementById('milkChart');

new Chart(ctx, {

    type: 'line',

    data: {

        labels: <?= json_encode($months) ?>,

        datasets: [{

            label: 'Milk Produced (L)',

            data: <?= json_encode($totals) ?>,

            borderWidth: 3,

            fill: true

        }]

    }

});

</script>

</body>
</html>