<?php

require '../includes/auth.php';
require '../config/database.php';

$expenses = $pdo->query("

SELECT
category,
SUM(amount) AS total

FROM expenses

GROUP BY category

")->fetchAll();

$totalExpenses = $pdo->query("
SELECT COALESCE(
SUM(amount),
0
)
FROM expenses
")->fetchColumn();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Expense Report</h2>

<table class="table table-bordered">

<tr>

<th>Category</th>
<th>Total</th>

</tr>

<?php foreach($expenses as $expense): ?>

<tr>

<td><?= $expense['category']; ?></td>

<td>
KES
<?= number_format($expense['total'],2); ?>
</td>

</tr>

<?php endforeach; ?>

<tr>

<th>Total Expenses</th>

<th>
KES
<?= number_format($totalExpenses,2); ?>
</th>

</tr>

</table>

<button onclick="window.print()"
class="btn btn-danger">

Print Report

</button>

</div>

</div>