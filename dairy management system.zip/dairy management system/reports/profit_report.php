<?php

require '../includes/auth.php';
require '../config/database.php';

$revenue = $pdo->query("
SELECT COALESCE(
SUM(total_amount),
0
)
FROM sales
")->fetchColumn();

$expenses = $pdo->query("
SELECT COALESCE(
SUM(amount),
0
)
FROM expenses
")->fetchColumn();

$profit = $revenue - $expenses;

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Profit Analysis Report</h2>

<table class="table table-bordered">

<tr>

<th>Total Revenue</th>

<td>
KES <?= number_format($revenue,2); ?>
</td>

</tr>

<tr>

<th>Total Expenses</th>

<td>
KES <?= number_format($expenses,2); ?>
</td>

</tr>

<tr>

<th>Net Profit</th>

<td>
KES <?= number_format($profit,2); ?>
</td>

</tr>

</table>

<button onclick="window.print()"
class="btn btn-dark">

Print Report

</button>

</div>

</div>