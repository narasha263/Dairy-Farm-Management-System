<?php

require '../config/database.php';

$totalMilk = $pdo->query("
SELECT COALESCE(SUM(total_milk),0)
FROM milk_production
")->fetchColumn();

$totalSales = $pdo->query("
SELECT COALESCE(SUM(total_amount),0)
FROM sales
")->fetchColumn();

$totalExpenses = $pdo->query("
SELECT COALESCE(SUM(amount),0)
FROM expenses
")->fetchColumn();

$totalProfit = $totalSales - $totalExpenses;


require '../includes/auth.php';

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">
<div class="row mb-4">

<div class="col-md-3">
<div class="card bg-primary text-white">
<div class="card-body">
<h6>Total Milk</h6>
<h3><?= $totalMilk ?> L</h3>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card bg-success text-white">
<div class="card-body">
<h6>Total Revenue</h6>
<h3>KES <?= number_format($totalSales) ?></h3>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card bg-danger text-white">
<div class="card-body">
<h6>Total Expenses</h6>
<h3>KES <?= number_format($totalExpenses) ?></h3>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card bg-dark text-white">
<div class="card-body">
<h6>Net Profit</h6>
<h3>KES <?= number_format($totalProfit) ?></h3>
</div>
</div>
</div>

</div>
<h2 class="mb-4">Reports Dashboard</h2>

<div class="row">

<div class="col-md-3 mb-3">
<div class="card shadow-sm">
<div class="card-body text-center">

<h5>Milk Report</h5>

<p>
View milk production statistics and summaries.
</p>

<a href="milk_report.php"
class="btn btn-primary">

Open Report

</a>

</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card shadow-sm">
<div class="card-body text-center">

<h5>Sales Report</h5>

<p>
View customer sales and revenue reports.
</p>

<a href="sales_report.php"
class="btn btn-success">

Open Report

</a>

</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card shadow-sm">
<div class="card-body text-center">

<h5>Expense Report</h5>

<p>
View all farm expenses and spending.
</p>

<a href="expense_report.php"
class="btn btn-danger">

Open Report

</a>

</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card shadow-sm">
<div class="card-body text-center">

<h5>Profit Report</h5>

<p>
Analyze farm profitability and earnings.
</p>

<a href="profit_report.php"
class="btn btn-dark">

Open Report

</a>

</div>
</div>
</div>

</div>

</div>

</div>