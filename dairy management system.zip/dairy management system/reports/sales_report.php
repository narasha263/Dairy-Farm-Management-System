<?php

require '../includes/auth.php';
require '../config/database.php';

$sales = $pdo->query("

SELECT
customers.full_name,
SUM(sales.total_amount) AS amount

FROM sales

JOIN customers
ON customers.id = sales.customer_id

GROUP BY customers.id

")->fetchAll();

$totalRevenue = $pdo->query("
SELECT COALESCE(
SUM(total_amount),
0
)
FROM sales
")->fetchColumn();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Sales Report</h2>

<table class="table table-bordered">

<tr>
<th>Customer</th>
<th>Amount</th>
</tr>

<?php foreach($sales as $sale): ?>

<tr>

<td><?= $sale['full_name']; ?></td>

<td>
KES
<?= number_format($sale['amount'],2); ?>
</td>

</tr>

<?php endforeach; ?>

<tr>

<th>Total Revenue</th>

<th>
KES
<?= number_format($totalRevenue,2); ?>
</th>

</tr>

</table>

<button onclick="window.print()"
class="btn btn-success">

Print Report

</button>

</div>

</div>