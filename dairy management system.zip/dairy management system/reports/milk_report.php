<?php

require '../includes/auth.php';
require '../config/database.php';

$sql = "
SELECT
cows.cow_code,
SUM(milk_production.total_milk) AS total_milk

FROM milk_production

JOIN cows
ON cows.id = milk_production.cow_id

GROUP BY cows.id
";

$records = $pdo->query($sql)->fetchAll();

$totalMilk = $pdo->query("
SELECT COALESCE(
SUM(total_milk),
0
)
FROM milk_production
")->fetchColumn();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Milk Production Report</h2>

<table class="table table-bordered">

<thead>

<tr>
<th>Cow</th>
<th>Total Milk (L)</th>
</tr>

</thead>

<tbody>

<?php foreach($records as $row): ?>

<tr>

<td><?= $row['cow_code']; ?></td>

<td><?= $row['total_milk']; ?></td>

</tr>

<?php endforeach; ?>

</tbody>

<tfoot>

<tr>

<th>Total</th>

<th><?= $totalMilk; ?> L</th>

</tr>

</tfoot>

</table>

<button onclick="window.print()"
class="btn btn-primary">

Print Report

</button>

</div>

</div>