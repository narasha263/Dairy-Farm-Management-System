<?php

require '../includes/auth.php';

if($_SESSION['role'] != 'admin'){

    die('Access Denied');

}

require '../includes/auth.php';

if($_SESSION['role'] != 'admin'){

    die('Access Denied');

}

require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
DELETE FROM users
WHERE id=?
");

$stmt->execute([$id]);

header("Location:index.php");
exit();