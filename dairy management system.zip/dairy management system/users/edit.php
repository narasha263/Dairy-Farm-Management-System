<?php

require '../includes/auth.php';

if($_SESSION['role'] != 'admin'){

    die('Access Denied');

}

require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
SELECT *
FROM users
WHERE id=?
");

$stmt->execute([$id]);

$user = $stmt->fetch();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Edit User</h2>

<form action="update.php" method="POST">

<input type="hidden"
       name="id"
       value="<?= $user['id']; ?>">

<div class="mb-3">

<label>Full Name</label>

<input type="text"
       name="fullname"
       value="<?= $user['fullname']; ?>"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Email</label>

<input type="email"
       name="email"
       value="<?= $user['email']; ?>"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Role</label>

<select name="role" class="form-control">

<option value="admin"
<?= $user['role']=='admin' ? 'selected' : ''; ?>>
Admin
</option>

<option value="manager"
<?= $user['role']=='manager' ? 'selected' : ''; ?>>
Manager
</option>

<option value="accountant"
<?= $user['role']=='accountant' ? 'selected' : ''; ?>>
Accountant
</option>
<option value="worker"
<?= $user['role']=='worker' ? 'selected' : ''; ?>>
Worker
</option>
</select>

</div>

<button class="btn btn-warning">
Update User
</button>

</form>

</div>

</div>