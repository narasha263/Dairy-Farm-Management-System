<?php

require '../includes/auth.php';

if($_SESSION['role'] != 'admin'){

    die('Access Denied');

}

require '../config/database.php';
$totalUsers = $pdo->query("
SELECT COUNT(*)
FROM users
")->fetchColumn();

$admins = $pdo->query("
SELECT COUNT(*)
FROM users
WHERE role='admin'
")->fetchColumn();

$managers = $pdo->query("
SELECT COUNT(*)
FROM users
WHERE role='manager'
")->fetchColumn();

$accountants = $pdo->query("
SELECT COUNT(*)
FROM users
WHERE role='accountant'
")->fetchColumn();
$users = $pdo->query("
SELECT *
FROM users
ORDER BY id DESC
")->fetchAll();
 
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">


<div class="row mb-4">

<div class="col-md-3">
<div class="card bg-primary text-white">
<div class="card-body">
<h6>Total Users</h6>
<h2><?= $totalUsers ?></h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card bg-dark text-white">
<div class="card-body">
<h6>Admins</h6>
<h2><?= $admins ?></h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card bg-success text-white">
<div class="card-body">
<h6>Managers</h6>
<h2><?= $managers ?></h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card bg-warning text-dark">
<div class="card-body">
<h6>Accountants</h6>
<h2><?= $accountants ?></h2>
</div>
</div>
</div>

</div>
<div class="d-flex justify-content-between">

<h2>User Management</h2>

<a href="create.php"
class="btn btn-primary">

Add User

</a>

</div>

<br>

<table class="table table-bordered">

<thead>

<tr>

<th>ID</th>
<th>Full Name</th>
<th>Email</th>
<th>Role</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php foreach($users as $user): ?>

<tr>

<td><?= $user['id']; ?></td>

<td><?= $user['fullname']; ?></td>

<td><?= $user['email']; ?></td>

<td><?= ucfirst($user['role']); ?></td>

<td>

<a href="edit.php?id=<?= $user['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $user['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this user?')">

Delete

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>