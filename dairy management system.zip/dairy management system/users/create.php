<?php

require '../includes/auth.php';

if($_SESSION['role'] != 'admin'){

    die('Access Denied');

}

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Add User</h2>

<form action="store.php" method="POST">

<div class="mb-3">

<label>Full Name</label>

<input type="text"
name="fullname"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Email</label>

<input type="email"
name="email"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Password</label>

<input type="password"
name="password"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Role</label>

<select name="role"
class="form-control">

<option value="admin">Admin</option>
<option value="manager">Manager</option>
<option value="accountant">Accountant</option>
<option value="worker">Worker</option>

</select>

</div>

<button class="btn btn-success">

Create User

</button>

</form>

</div>

</div>