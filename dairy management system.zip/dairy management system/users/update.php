<?php

require '../includes/auth.php';

if($_SESSION['role'] != 'admin'){

    die('Access Denied');

}

require '../config/database.php';

$stmt = $pdo->prepare("
UPDATE users
SET
fullname=?,
email=?,
role=?
WHERE id=?
");

$stmt->execute([

$_POST['fullname'],
$_POST['email'],
$_POST['role'],
$_POST['id']

]);

header("Location:index.php");
exit();