<?php

require '../includes/auth.php';

if($_SESSION['role'] != 'admin'){

    die('Access Denied');

}
require '../config/database.php';

$fullname = $_POST['fullname'];
$email = $_POST['email'];

$password =
password_hash(
$_POST['password'],
PASSWORD_DEFAULT
);

$role = $_POST['role'];

$sql = "
INSERT INTO users(
fullname,
email,
password,
role
)
VALUES(
?,?,?,?
)
";

$stmt = $pdo->prepare($sql);

$stmt->execute([

$fullname,
$email,
$password,
$role

]);

header("Location:index.php");
exit();