<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager',
    'worker'
]);

require '../config/database.php';

$totalMilk = $pdo->query("
SELECT COALESCE(
SUM(total_milk),
0
)
FROM milk_production
")->fetchColumn();

$todayMilk = $pdo->query("
SELECT COALESCE(
SUM(total_milk),
0
)
FROM milk_production
WHERE production_date = CURDATE()
")->fetchColumn();



$sql = "
SELECT
milk_production.*,
cows.cow_code,
cows.breed

FROM milk_production

JOIN cows
ON cows.id = milk_production.cow_id

ORDER BY production_date DESC
";

$records = $pdo->query($sql)->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<div class="d-flex justify-content-between">

<div class="row mb-4">

<div class="col-md-6">

<div class="card bg-primary text-white">

<div class="card-body">

<h6>Milk Produced Today</h6>

<h2><?= $todayMilk ?> L</h2>

</div>

</div>

</div>

<div class="col-md-6">

<div class="card bg-success text-white">

<div class="card-body">

<h6>Total Milk Produced</h6>

<h2><?= $totalMilk ?> L</h2>

</div>

</div>

</div>

</div>
</div>
<div class="d-flex justify-content-between mb-3">

    <h2>Milk Production</h2>

    <a href="create.php" class="btn btn-success">
        Add Milk Record
    </a>

</div>
<br>

<table class="table table-bordered">

<thead>

<tr>

<th>Date</th>
<th>Cow</th>
<th>Breed</th>
<th>Morning</th>
<th>Evening</th>
<th>Total</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php foreach($records as $record): ?>

<tr>

<td><?= $record['production_date']; ?></td>
<td><?= $record['cow_code']; ?></td>
<td><?= $record['breed']; ?></td>
<td><?= $record['morning_milk']; ?> L</td>
<td><?= $record['evening_milk']; ?> L</td>
<td><?= $record['total_milk']; ?> L</td>

<td>

<a href="edit.php?id=<?= $record['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $record['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this record?')">

Delete

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>