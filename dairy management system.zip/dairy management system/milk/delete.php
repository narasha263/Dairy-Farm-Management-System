<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager'
]);


require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
DELETE FROM milk_production
WHERE id=?
");

$stmt->execute([$id]);

header("Location:index.php");
exit();