<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager'
]);

require '../includes/auth.php';
require '../config/database.php';

$cows = $pdo->query("
    SELECT * FROM cows
    WHERE gender='Female'
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Record Milk Production</h2>

<form action="store.php" method="POST">

<div class="mb-3">

<label>Cow</label>

<select name="cow_id" class="form-control">

<?php foreach($cows as $cow): ?>

<option value="<?= $cow['id']; ?>">

<?= $cow['cow_code']; ?>
-
<?= $cow['breed']; ?>

</option>

<?php endforeach; ?>

</select>

</div>

<div class="mb-3">

<label>Date</label>

<input type="date"
       name="production_date"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Morning Milk (L)</label>

<input type="number"
       step="0.01"
       name="morning_milk"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Evening Milk (L)</label>

<input type="number"
       step="0.01"
       name="evening_milk"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Notes</label>

<textarea name="notes"
          class="form-control"></textarea>

</div>

<button class="btn btn-success">

Save Record

</button>

</form>

</div>
</div>