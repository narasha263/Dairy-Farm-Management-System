<?php

require '../config/database.php';

$cow_id = $_POST['cow_id'];
$date = $_POST['production_date'];

$morning = $_POST['morning_milk'];
$evening = $_POST['evening_milk'];

$total = $morning + $evening;

$notes = $_POST['notes'];

$sql = "
INSERT INTO milk_production(
cow_id,
production_date,
morning_milk,
evening_milk,
total_milk,
notes
)
VALUES(
?,?,?,?,?,?
)
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    $cow_id,
    $date,
    $morning,
    $evening,
    $total,
    $notes
]);

header("Location:index.php");
exit();