<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager'
]);



require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
SELECT *
FROM milk_production
WHERE id=?
");

$stmt->execute([$id]);

$record = $stmt->fetch();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Edit Milk Record</h2>

<form action="update.php" method="POST">

<input type="hidden"
name="id"
value="<?= $record['id']; ?>">

<div class="mb-3">

<label>Morning Milk</label>

<input type="number"
step="0.01"
name="morning_milk"
value="<?= $record['morning_milk']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Evening Milk</label>

<input type="number"
step="0.01"
name="evening_milk"
value="<?= $record['evening_milk']; ?>"
class="form-control">

</div>

<button class="btn btn-warning">

Update Record

</button>

</form>

</div>

</div>