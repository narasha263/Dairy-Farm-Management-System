<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager'
]);



require '../config/database.php';

$id = $_POST['id'];

$morning = $_POST['morning_milk'];
$evening = $_POST['evening_milk'];

$total = $morning + $evening;

$stmt = $pdo->prepare("
UPDATE milk_production
SET
morning_milk=?,
evening_milk=?,
total_milk=?
WHERE id=?
");

$stmt->execute([
$morning,
$evening,
$total,
$id
]);

header("Location:index.php");
exit();