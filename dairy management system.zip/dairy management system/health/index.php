<?php

require '../includes/auth.php';
require '../config/database.php';

$sql = "
SELECT
h.*,
c.cow_code

FROM health_records h

JOIN cows c
ON c.id = h.cow_id

ORDER BY h.treatment_date DESC
";

$records = $pdo->query($sql)->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<div class="d-flex justify-content-between">

<h2>Health Records</h2>

<a href="create.php"
class="btn btn-primary">

Add Record

</a>

</div>

<br>

<table class="table table-bordered">

<thead>

<tr>

<th>Cow</th>
<th>Disease</th>
<th>Treatment</th>
<th>Veterinarian</th>
<th>Date</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php foreach($records as $record): ?>

<tr>

<td><?= $record['cow_code']; ?></td>
<td><?= $record['disease']; ?></td>
<td><?= $record['treatment']; ?></td>
<td><?= $record['veterinarian']; ?></td>
<td><?= $record['treatment_date']; ?></td>

<td>

<a href="edit.php?id=<?= $record['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $record['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete record?')">

Delete

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>