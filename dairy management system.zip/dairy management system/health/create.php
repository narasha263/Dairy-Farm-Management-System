<?php

require '../includes/auth.php';
require '../config/database.php';

$cows = $pdo->query("
SELECT *
FROM cows
ORDER BY cow_code
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Add Health Record</h2>

<form action="store.php" method="POST">

<div class="mb-3">

<label>Cow</label>

<select name="cow_id" class="form-control" required>

<?php foreach($cows as $cow): ?>

<option value="<?= $cow['id']; ?>">
<?= $cow['cow_code']; ?>
</option>

<?php endforeach; ?>

</select>

</div>

<div class="mb-3">

<label>Disease</label>

<input type="text"
name="disease"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Treatment</label>

<textarea
name="treatment"
class="form-control"
required></textarea>

</div>

<div class="mb-3">

<label>Veterinarian</label>

<input type="text"
name="veterinarian"
class="form-control">

</div>

<div class="mb-3">

<label>Treatment Date</label>

<input type="date"
name="treatment_date"
class="form-control"
required>

</div>

<button class="btn btn-primary">
Save Record
</button>

</form>

</div>

</div>