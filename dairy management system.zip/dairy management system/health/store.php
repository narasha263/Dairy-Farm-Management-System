<?php

require '../config/database.php';

$stmt = $pdo->prepare("
INSERT INTO health_records
(
cow_id,
disease,
treatment,
veterinarian,
treatment_date
)
VALUES
(
?,?,?,?,?
)
");

$stmt->execute([

$_POST['cow_id'],
$_POST['disease'],
$_POST['treatment'],
$_POST['veterinarian'],
$_POST['treatment_date']

]);

header("Location:index.php");
exit();