<?php

require '../includes/auth.php';
require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
SELECT *
FROM health_records
WHERE id=?
");

$stmt->execute([$id]);

$record = $stmt->fetch();

$cows = $pdo->query("
SELECT *
FROM cows
ORDER BY cow_code
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Edit Health Record</h2>

<form action="update.php" method="POST">

<input type="hidden"
name="id"
value="<?= $record['id']; ?>">

<div class="mb-3">

<label>Cow</label>

<select name="cow_id" class="form-control">

<?php foreach($cows as $cow): ?>

<option
value="<?= $cow['id']; ?>"
<?= $cow['id']==$record['cow_id'] ? 'selected' : '' ?>>

<?= $cow['cow_code']; ?>

</option>

<?php endforeach; ?>

</select>

</div>

<div class="mb-3">

<label>Disease</label>

<input type="text"
name="disease"
value="<?= $record['disease']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Treatment</label>

<textarea
name="treatment"
class="form-control"><?= $record['treatment']; ?></textarea>

</div>

<div class="mb-3">

<label>Veterinarian</label>

<input type="text"
name="veterinarian"
value="<?= $record['veterinarian']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Treatment Date</label>

<input type="date"
name="treatment_date"
value="<?= $record['treatment_date']; ?>"
class="form-control">

</div>

<button class="btn btn-warning">
Update Record
</button>

</form>

</div>

</div>