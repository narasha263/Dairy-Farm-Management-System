<?php

require '../config/database.php';

$stmt = $pdo->prepare("
UPDATE health_records
SET
cow_id=?,
disease=?,
treatment=?,
veterinarian=?,
treatment_date=?
WHERE id=?
");

$stmt->execute([

$_POST['cow_id'],
$_POST['disease'],
$_POST['treatment'],
$_POST['veterinarian'],
$_POST['treatment_date'],
$_POST['id']

]);

header("Location:index.php");
exit();