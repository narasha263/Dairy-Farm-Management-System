<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager'
]);

require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
SELECT *
FROM cows
WHERE id=?
");

$stmt->execute([$id]);

$cow = $stmt->fetch();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Edit Cow</h2>

<form action="update.php" method="POST">

<input type="hidden"
       name="id"
       value="<?= $cow['id']; ?>">

<div class="mb-3">
<label>Cow Code</label>
<input type="text"
       name="cow_code"
       class="form-control"
       value="<?= $cow['cow_code']; ?>">
</div>

<div class="mb-3">
<label>Tag Number</label>
<input type="text"
       name="tag_number"
       class="form-control"
       value="<?= $cow['tag_number']; ?>">
</div>

<div class="mb-3">
<label>Breed</label>
<input type="text"
       name="breed"
       class="form-control"
       value="<?= $cow['breed']; ?>">
</div>

<div class="mb-3">
<label>Status</label>

<select name="status"
        class="form-control">

<option value="Healthy"
<?= $cow['status']=='Healthy' ? 'selected' : ''; ?>>
Healthy
</option>

<option value="Pregnant"
<?= $cow['status']=='Pregnant' ? 'selected' : ''; ?>>
Pregnant
</option>

<option value="Sick"
<?= $cow['status']=='Sick' ? 'selected' : ''; ?>>
Sick
</option>

</select>

</div>

<button class="btn btn-warning">
Update Cow
</button>

</form>

</div>

</div>