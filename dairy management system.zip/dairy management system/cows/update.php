<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager'
]);

require '../config/database.php';

$sql = "
UPDATE cows
SET
cow_code=?,
tag_number=?,
breed=?,
status=?
WHERE id=?
";

$stmt = $pdo->prepare($sql);

$stmt->execute([

$_POST['cow_code'],
$_POST['tag_number'],
$_POST['breed'],
$_POST['status'],
$_POST['id']

]);

header("Location:index.php");
exit();