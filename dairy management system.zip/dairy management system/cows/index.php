<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager'
]);

require '../config/database.php';

$cows = $pdo->query(
    "SELECT * FROM cows ORDER BY id DESC"
)->fetchAll();


include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">


<div class="d-flex justify-content-between mb-3">

<h2>Cow Management</h2>

<a href="create.php"
   class="btn btn-success">

Add Cow

</a>

</div>

<table class="table table-bordered">

<thead>

<tr>

<th>ID</th>
<th>Photo</th>
<th>Cow Code</th>
<th>Tag</th>
<th>Breed</th>
<th>Status</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php foreach($cows as $cow): ?>

<tr>

<td><?= $cow['id']; ?></td>

<td>

<?php if($cow['photo']): ?>

<img src="../assets/uploads/cows/<?= $cow['photo']; ?>"
     width="60">

<?php endif; ?>

</td>

<td><?= $cow['cow_code']; ?></td>

<td><?= $cow['tag_number']; ?></td>

<td><?= $cow['breed']; ?></td>

<td><?= $cow['status']; ?></td>

<td>

<a href="edit.php?id=<?= $cow['id']; ?>"
   class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $cow['id']; ?>"
   class="btn btn-danger btn-sm">

Delete

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>