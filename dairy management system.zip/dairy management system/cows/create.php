
<?php

require '../includes/auth.php';
require '../includes/role_check.php';

checkRole([
    'admin',
    'manager'
]);

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Add New Cow</h2>

<form action="store.php"
      method="POST"
      enctype="multipart/form-data">

<div class="mb-3">

<label>Cow Code</label>

<input type="text"
       name="cow_code"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Tag Number</label>

<input type="text"
       name="tag_number"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Breed</label>

<input type="text"
       name="breed"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Gender</label>

<select name="gender"
        class="form-control">

<option>Male</option>
<option>Female</option>

</select>

</div>

<div class="mb-3">

<label>Date of Birth</label>

<input type="date"
       name="date_of_birth"
       class="form-control">

</div>

<div class="mb-3">

<label>Weight (Kg)</label>

<input type="number"
       step="0.01"
       name="weight"
       class="form-control">

</div>

<div class="mb-3">

<label>Status</label>

<select name="status"
        class="form-control">

<option>Healthy</option>
<option>Sick</option>
<option>Pregnant</option>
<option>Dry</option>

</select>

</div>

<div class="mb-3">

<label>Purchase Date</label>

<input type="date"
       name="purchase_date"
       class="form-control">

</div>

<div class="mb-3">

<label>Photo</label>

<input type="file"
       name="photo"
       class="form-control">

</div>

<button class="btn btn-success">
Save Cow
</button>

</form>

</div>
</div>