<?php

require '../config/database.php';

$cow_code = $_POST['cow_code'];
$tag_number = $_POST['tag_number'];
$breed = $_POST['breed'];
$gender = $_POST['gender'];
$date_of_birth = $_POST['date_of_birth'];
$weight = $_POST['weight'];
$status = $_POST['status'];
$purchase_date = $_POST['purchase_date'];

$photo = '';

if(!empty($_FILES['photo']['name'])){

    $photo =
        time() .
        '_' .
        $_FILES['photo']['name'];

    move_uploaded_file(
        $_FILES['photo']['tmp_name'],
        "../assets/uploads/cows/" . $photo
    );
}

$sql = "
INSERT INTO cows(
cow_code,
tag_number,
breed,
gender,
date_of_birth,
weight,
status,
photo,
purchase_date
)
VALUES(
?,?,?,?,?,?,?,?,?
)
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    $cow_code,
    $tag_number,
    $breed,
    $gender,
    $date_of_birth,
    $weight,
    $status,
    $photo,
    $purchase_date
]);

header("Location:index.php");
exit();