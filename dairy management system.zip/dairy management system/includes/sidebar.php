<?php if(
$_SESSION['role']=='admin'
): ?>

<div class="sidebar">

    <h4 class="logo">Dairy Management System</h4>

    <ul>

        <li>
            <a href="../dashboard/index.php">
                Dashboard
            </a>
        </li>

            <li>
    <a href="../cows/index.php">
<i class="bi bi-cow"></i> Cow Management
    </a>
</li>


     <li>
    <a href="../milk/index.php">
<i class="bi bi-house"></i> Milk Production
    </a>
</li>
 <li>
    <a href="../customers/index.php">
<i class="bi bi-people"></i> Customers
    </a>
</li>
  
        <li>
               <a href="../sales/index.php">

            <i class="bi bi-cash"></i> Sales
            </a>
        </li>

        
        <li>
             <a href="../expenses/index.php">
                Expenses
            </a>
        </li>   
         <li>
    <a href="../profit/index.php">
        Profit Analysis
    </a>
</li>

<li>
    <a href="../reports/index.php">
        Reports
    </a>
</li>
<li>
    <a href="../users/index.php">
        User Management
    </a>
</li>
        <li>
            <a href="../auth/logout.php">
                Logout
            </a>
        </li>

    </ul>

</div>
<?php endif; ?>

<?php if(
$_SESSION['role']=='manager'
): ?>
<div class="sidebar">

    <h4 class="logo">Dairy Management System</h4>

    <ul>

        <li>
            <a href="../dashboard/index.php">
                Dashboard
            </a>
        </li>

            <li>
    <a href="../cows/index.php">
<i class="bi bi-cow"></i> Cow Management
    </a>
</li>

     <li>
    <a href="../milk/index.php">
<i class="bi bi-house"></i> Milk Production
    </a>
</li>
<li>
<a href="../health/index.php">
Health Records
</a>
</li>

<li>
<a href="../vaccinations/index.php">

Vaccinations
</a>
</li>

<li>
<a href="../breeding/index.php">
Breeding
</a>
</li>
<li>
 <a href="../reports/index.php">
        Reports
    </a>
</li>
        <li>
            <a href="../auth/logout.php">
                Logout
            </a>
        </li>

    </ul>

</div>
<?php endif; ?>

<?php if(
$_SESSION['role']=='accountant'
): ?>
<div class="sidebar">

  <h4 class="logo">Dairy Management System</h4>

    <ul>

        <li>
            <a href="../dashboard/index.php">
                Dashboard
            </a>
        </li>
         <li>
    <a href="../customers/index.php">
<i class="bi bi-people"></i> Customers
    </a>
</li>
  
        <li>
               <a href="../sales/index.php">

           <i class="bi bi-cash-stack"></i> Sales
            </a>
        </li>

        
        <li>
             <a href="../expenses/index.php">
                Expenses
            </a>
        </li>
        
     <li>
    <a href="../profit/index.php">
        Profit Analysis
    </a>
</li>

      
<li>
    <a href="../reports/index.php">
        Reports
    </a>
</li>

     <li>
            <a href="../auth/logout.php">
                Logout
            </a>
        </li>

    </ul>

</div>
    <?php endif; ?>


<?php if($_SESSION['role']=='worker'): ?>

<div class="sidebar">

    <h4 class="logo">Dairy Management System</h4>

    <ul>

        <li>
            <a href="../dashboard/index.php">
                Dashboard
            </a>
        </li>

        <li>
            <a href="../milk/index.php">
                Milk Production
            </a>
        </li>

        <li>
            <a href="../health/index.php">
                Health Records
            </a>
        </li>

        <li>
            <a href="../auth/logout.php">
                Logout
            </a>
        </li>

    </ul>

</div>

<?php endif; ?>