<div class="navbar-custom">

    <div>
        Welcome,
        <?php echo $_SESSION['fullname']; ?>
    </div>

    <div>
        <?php echo ucfirst($_SESSION['role']); ?>
    </div>

</div>