<?php

function checkRole($allowedRoles){

    if(
        !isset($_SESSION['role']) ||
        !in_array($_SESSION['role'], $allowedRoles)
    ){
        die("Access Denied");
    }

}