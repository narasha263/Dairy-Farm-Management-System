<?php

require '../includes/auth.php';
require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
SELECT *
FROM sales
WHERE id=?
");

$stmt->execute([$id]);

$sale = $stmt->fetch();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Edit Sale</h2>

<form action="update.php" method="POST">

<input type="hidden"
name="id"
value="<?= $sale['id']; ?>">

<div class="mb-3">

<label>Quantity</label>

<input type="number"
step="0.01"
name="quantity"
value="<?= $sale['quantity']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Price Per Litre</label>

<input type="number"
step="0.01"
name="price_per_litre"
value="<?= $sale['price_per_litre']; ?>"
class="form-control">

</div>

<div class="mb-3">

<label>Payment Method</label>

<input type="text"
name="payment_method"
value="<?= $sale['payment_method']; ?>"
class="form-control">

</div>

<button class="btn btn-warning">

Update Sale

</button>

</form>

</div>

</div>