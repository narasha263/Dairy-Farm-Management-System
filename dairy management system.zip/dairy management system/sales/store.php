<?php

require '../config/database.php';

$sql = "
INSERT INTO sales(
customer_id,
quantity,
price_per_litre,
total_amount,
payment_method,
sale_date
)
VALUES(
?,?,?,?,?,?
)
";

$stmt = $pdo->prepare($sql);

$stmt->execute([

$_POST['customer_id'],
$_POST['quantity'],
$_POST['price_per_litre'],
$_POST['total_amount'],
$_POST['payment_method'],
$_POST['sale_date']

]);

header("Location:index.php");
exit();