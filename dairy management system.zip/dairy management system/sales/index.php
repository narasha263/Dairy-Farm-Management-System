<?php

require '../includes/auth.php';

if(
    $_SESSION['role']!='admin' &&
    $_SESSION['role']!='accountant'
){
    die("Access Denied");
}


require '../config/database.php';

$totalRevenue = $pdo->query("
SELECT COALESCE(
SUM(total_amount),
0
)
FROM sales
")->fetchColumn();

$todayRevenue = $pdo->query("
SELECT COALESCE(
SUM(total_amount),
0
)
FROM sales
WHERE sale_date = CURDATE()
")->fetchColumn();

$totalSales = $pdo->query("
SELECT COUNT(*)
FROM sales
")->fetchColumn();

$sales = $pdo->query("

SELECT
sales.*,
customers.full_name

FROM sales

JOIN customers
ON customers.id=sales.customer_id

ORDER BY sales.id DESC

")->fetchAll();


include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

    <div class="row mb-4">

<div class="col-md-4">

<div class="card bg-success text-white">

<div class="card-body">

<h6>Today's Revenue</h6>

<h2>
KES <?= number_format($todayRevenue) ?>
</h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-primary text-white">

<div class="card-body">

<h6>Total Revenue</h6>

<h2>
KES <?= number_format($totalRevenue) ?>
</h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-dark text-white">

<div class="card-body">

<h6>Total Sales Records</h6>

<h2>
<?= $totalSales ?>
</h2>

</div>

</div>

</div>

</div>

<div class="d-flex justify-content-between">

<h2>Sales</h2>

<a href="create.php"
class="btn btn-success">

Record Sale

</a>

</div>

<br>

<table class="table table-bordered">

<thead>

<tr>

<th>Date</th>
<th>Customer</th>
<th>Quantity</th>
<th>Price/L</th>
<th>Total</th>
<th>Payment</th>
<th>Actions</th>

</tr>


</thead>

<tbody>
    

<?php foreach($sales as $sale): ?>
    

<tr>
    

<td><?= $sale['sale_date'] ?></td>

<td><?= $sale['full_name'] ?></td>

<td><?= $sale['quantity'] ?> L</td>

<td>KES <?= number_format($sale['price_per_litre'],2) ?></td>

<td>KES <?= number_format($sale['total_amount'],2) ?></td>

<td><?= $sale['payment_method'] ?></td>
<td>

<a href="edit.php?id=<?= $sale['id'] ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $sale['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this sale?')">

Delete

</a>

</td>

</tr>


<?php endforeach; ?>

</tbody>

</table>

</div>

</div>