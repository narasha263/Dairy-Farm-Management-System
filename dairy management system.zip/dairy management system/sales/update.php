<?php

require '../config/database.php';

$id = $_POST['id'];

$quantity = $_POST['quantity'];

$price = $_POST['price_per_litre'];

$total = $quantity * $price;

$stmt = $pdo->prepare("
UPDATE sales
SET
quantity=?,
price_per_litre=?,
total_amount=?,
payment_method=?
WHERE id=?
");

$stmt->execute([

$quantity,
$price,
$total,
$_POST['payment_method'],
$id

]);

header("Location:index.php");
exit();