<?php

require '../includes/auth.php';
require '../config/database.php';

$customers = $pdo->query("
SELECT *
FROM customers
ORDER BY full_name
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Record Sale</h2>

<form action="store.php" method="POST">

<div class="mb-3">

<label>Customer</label>

<select name="customer_id"
        class="form-control"
        required>

<?php foreach($customers as $customer): ?>

<option value="<?= $customer['id'] ?>">

<?= $customer['full_name'] ?>

</option>

<?php endforeach; ?>

</select>

</div>

<div class="mb-3">

<label>Quantity (Litres)</label>

<input type="number"
       step="0.01"
       name="quantity"
       id="quantity"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Price Per Litre</label>

<input type="number"
       step="0.01"
       name="price_per_litre"
       id="price"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Total Amount</label>

<input type="number"
       step="0.01"
       name="total_amount"
       id="total"
       class="form-control"
       readonly>

</div>

<div class="mb-3">

<label>Payment Method</label>

<select name="payment_method"
        class="form-control">

<option>Cash</option>
<option>M-Pesa</option>
<option>Bank</option>

</select>

</div>

<div class="mb-3">

<label>Sale Date</label>

<input type="date"
       name="sale_date"
       value="<?= date('Y-m-d') ?>"
       class="form-control">

</div>

<button class="btn btn-success">

Save Sale

</button>

</form>

</div>

</div>

<script>

const quantity =
document.getElementById('quantity');

const price =
document.getElementById('price');

const total =
document.getElementById('total');

function calculate(){

total.value =
(quantity.value || 0)
*
(price.value || 0);

}

quantity.addEventListener(
'input',
calculate
);

price.addEventListener(
'input',
calculate
);

</script>