-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jun 05, 2026 at 11:07 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dairy_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `breeding`
--

CREATE TABLE `breeding` (
  `id` int(11) NOT NULL,
  `cow_id` int(11) NOT NULL,
  `service_date` date DEFAULT NULL,
  `semen_source` varchar(100) DEFAULT NULL,
  `expected_calving_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `breeding`
--

INSERT INTO `breeding` (`id`, `cow_id`, `service_date`, `semen_source`, `expected_calving_date`, `status`) VALUES
(1, 1, '2026-05-31', 'AI', '2026-08-26', 'Pregnant'),
(2, 3, '2026-06-03', 'Cross breeding', '2026-09-16', 'Open');

-- --------------------------------------------------------

--
-- Table structure for table `cows`
--

CREATE TABLE `cows` (
  `id` int(11) NOT NULL,
  `cow_code` varchar(20) NOT NULL,
  `tag_number` varchar(50) NOT NULL,
  `breed` varchar(100) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `weight` decimal(10,2) DEFAULT NULL,
  `status` enum('Healthy','Sick','Pregnant','Dry') DEFAULT 'Healthy',
  `photo` varchar(255) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cows`
--

INSERT INTO `cows` (`id`, `cow_code`, `tag_number`, `breed`, `gender`, `date_of_birth`, `weight`, `status`, `photo`, `purchase_date`, `created_at`) VALUES
(1, '1', '34', 'Friesian', 'Female', '2021-01-07', 700.00, 'Healthy', '1780328446_friesian.webp', '0000-00-00', '2026-06-01 15:40:46'),
(3, '2', '35', 'Aryshire', 'Female', '2020-06-04', 700.00, 'Sick', '1780595475_aryshire.jpeg', '2026-05-31', '2026-06-04 17:51:15'),
(4, '3', '36', 'Guernsey', 'Female', '2019-10-10', 600.00, 'Healthy', '1780646009_guernsey.jpg', '2026-05-31', '2026-06-05 07:53:29');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `customer_code` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customer_code`, `full_name`, `phone`, `email`, `address`, `created_at`) VALUES
(1, '009', 'Alice nina', '0796139521', 'alice@gmail.com', 'thika', '2026-06-02 18:45:03'),
(6, '4', 'washuka unice', '079867452', 'washuka@gmail.com', 'konza', '2026-06-05 07:39:53');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `expense_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `category`, `amount`, `description`, `expense_date`, `created_at`) VALUES
(1, 'Feed', 3000.00, 'Animal feeds', '2026-06-04', '2026-06-04 06:49:28'),
(2, 'Veterinary', 5000.00, 'dipping and injection', '2026-06-05', '2026-06-05 07:27:16'),
(3, 'Equipment', 7500.00, 'new equipements', '2026-06-02', '2026-06-05 07:30:06'),
(4, 'Equipment', 7500.00, 'milking equipments and a new cow shed was needed', '2026-06-03', '2026-06-05 07:31:29');

-- --------------------------------------------------------

--
-- Table structure for table `health_records`
--

CREATE TABLE `health_records` (
  `id` int(11) NOT NULL,
  `cow_id` int(11) NOT NULL,
  `disease` varchar(100) DEFAULT NULL,
  `treatment` text DEFAULT NULL,
  `veterinarian` varchar(100) DEFAULT NULL,
  `treatment_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `health_records`
--

INSERT INTO `health_records` (`id`, `cow_id`, `disease`, `treatment`, `veterinarian`, `treatment_date`) VALUES
(1, 1, 'Foot and Mouth', 'injection', 'cashmer', '2026-05-31'),
(2, 3, 'Mastitis', 'Mastitis (Udder Infection): Clean the teat, strip the infected milk, and infuse an intramammary antibiotic tube directly into the teat canal. Use systemic antibiotics for severe, feverish cases.', 'cashmer', '2026-06-01');

-- --------------------------------------------------------

--
-- Table structure for table `milk_production`
--

CREATE TABLE `milk_production` (
  `id` int(11) NOT NULL,
  `cow_id` int(11) NOT NULL,
  `production_date` date NOT NULL,
  `morning_milk` decimal(10,2) DEFAULT 0.00,
  `evening_milk` decimal(10,2) DEFAULT 0.00,
  `total_milk` decimal(10,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `milk_production`
--

INSERT INTO `milk_production` (`id`, `cow_id`, `production_date`, `morning_milk`, `evening_milk`, `total_milk`, `notes`, `created_at`) VALUES
(1, 1, '2026-06-09', 30.00, 20.00, 50.00, '70 litrs per day', '2026-06-02 18:00:02'),
(2, 1, '2026-06-02', 59.00, 70.00, 129.00, '150 Litres today', '2026-06-02 18:36:24'),
(3, 1, '2026-02-16', 30.00, 30.00, 60.00, '60', '2026-06-02 18:37:33'),
(4, 3, '2026-06-05', 30.00, 59.98, 89.98, 'good condition', '2026-06-05 07:55:02');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `price_per_litre` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` enum('Cash','M-Pesa','Bank') DEFAULT 'Cash',
  `sale_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `customer_id`, `quantity`, `price_per_litre`, `total_amount`, `payment_method`, `sale_date`, `created_at`) VALUES
(1, 1, 340.00, 100.00, 34000.00, 'Cash', '2026-06-02', '2026-06-02 18:54:07'),
(2, 1, 50.00, 100.00, 5000.00, 'M-Pesa', '2026-06-05', '2026-06-05 07:25:54'),
(3, 1, 60.00, 100.00, 6000.00, 'M-Pesa', '2026-06-03', '2026-06-05 07:28:07'),
(4, 6, 20.00, 100.00, 2000.00, 'Cash', '2026-06-05', '2026-06-05 07:57:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','manager','accountant','worker') DEFAULT 'worker',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Admin', 'admin@dairy.com', '$2y$10$83VWThMgXjSoDuBRhrhi5egqS4Ew02RN0ZSB2XW/ZXVZln19FZbn2', 'admin', '2026-06-01 15:11:46'),
(2, 'Njeri esther', 'manager@gmail.com', '$2y$10$b9GISf3hOxruL0dZ6.Zv0eh4Pqzsg849S8p8K0aXS2NYHQaab8V.K', 'manager', '2026-06-02 19:42:31'),
(3, 'Joan esther', 'accountant@gmail.com', '$2y$10$GyIHyX6WdsNalKTOyVGeq..4h4Y4gVvZPd2MDB0dvgc0O4B4ul0Xm', 'accountant', '2026-06-04 08:05:07'),
(7, 'Erick Worker', 'worker@gmail.com', '$2y$10$Vn.hBSK5c34ygyNbaJbk1.NCP9LElhyeF/ZgAOvYHUAK55dIDjNPK', 'worker', '2026-06-04 18:14:45');

-- --------------------------------------------------------

--
-- Table structure for table `vaccinations`
--

CREATE TABLE `vaccinations` (
  `id` int(11) NOT NULL,
  `cow_id` int(11) NOT NULL,
  `vaccine_name` varchar(100) DEFAULT NULL,
  `date_given` date DEFAULT NULL,
  `next_due_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaccinations`
--

INSERT INTO `vaccinations` (`id`, `cow_id`, `vaccine_name`, `date_given`, `next_due_date`) VALUES
(1, 1, 'Fotivax™ ', '2026-06-01', '2026-06-08'),
(2, 3, 'Dipping', '2026-06-02', '2026-06-07'),
(3, 1, 'Fotivax™ ', '2026-05-13', '2026-05-26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `breeding`
--
ALTER TABLE `breeding`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cow_id` (`cow_id`);

--
-- Indexes for table `cows`
--
ALTER TABLE `cows`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cow_code` (`cow_code`),
  ADD UNIQUE KEY `tag_number` (`tag_number`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_code` (`customer_code`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `health_records`
--
ALTER TABLE `health_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cow_id` (`cow_id`);

--
-- Indexes for table `milk_production`
--
ALTER TABLE `milk_production`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cow_id` (`cow_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vaccinations`
--
ALTER TABLE `vaccinations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cow_id` (`cow_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `breeding`
--
ALTER TABLE `breeding`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cows`
--
ALTER TABLE `cows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `health_records`
--
ALTER TABLE `health_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `milk_production`
--
ALTER TABLE `milk_production`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `vaccinations`
--
ALTER TABLE `vaccinations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `breeding`
--
ALTER TABLE `breeding`
  ADD CONSTRAINT `breeding_ibfk_1` FOREIGN KEY (`cow_id`) REFERENCES `cows` (`id`);

--
-- Constraints for table `health_records`
--
ALTER TABLE `health_records`
  ADD CONSTRAINT `health_records_ibfk_1` FOREIGN KEY (`cow_id`) REFERENCES `cows` (`id`);

--
-- Constraints for table `milk_production`
--
ALTER TABLE `milk_production`
  ADD CONSTRAINT `milk_production_ibfk_1` FOREIGN KEY (`cow_id`) REFERENCES `cows` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vaccinations`
--
ALTER TABLE `vaccinations`
  ADD CONSTRAINT `vaccinations_ibfk_1` FOREIGN KEY (`cow_id`) REFERENCES `cows` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
