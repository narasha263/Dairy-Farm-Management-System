<?php

require '../includes/auth.php';
require '../config/database.php';

$sql = "
UPDATE customers
SET
customer_code=?,
full_name=?,
phone=?,
email=?,
address=?
WHERE id=?
";

$stmt = $pdo->prepare($sql);

$stmt->execute([

$_POST['customer_code'],
$_POST['full_name'],
$_POST['phone'],
$_POST['email'],
$_POST['address'],
$_POST['id']

]);

header("Location:index.php");
exit();