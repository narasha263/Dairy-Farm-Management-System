<?php

require '../includes/auth.php';

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Add Customer</h2>

<form action="store.php" method="POST">

<div class="mb-3">

<label>Customer Code</label>

<input type="text"
       name="customer_code"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Full Name</label>

<input type="text"
       name="full_name"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Phone Number</label>

<input type="text"
       name="phone"
       class="form-control">

</div>

<div class="mb-3">

<label>Email</label>

<input type="email"
       name="email"
       class="form-control">

</div>

<div class="mb-3">

<label>Address</label>

<textarea name="address"
          class="form-control"></textarea>

</div>

<button class="btn btn-success">

Save Customer

</button>

</form>

</div>
</div>