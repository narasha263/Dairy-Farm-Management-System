<?php

require '../config/database.php';

$customer_code = $_POST['customer_code'];
$full_name = $_POST['full_name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$address = $_POST['address'];

$sql = "
INSERT INTO customers(
customer_code,
full_name,
phone,
email,
address
)
VALUES(
?,?,?,?,?
)
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    $customer_code,
    $full_name,
    $phone,
    $email,
    $address
]);

header("Location:index.php");
exit();