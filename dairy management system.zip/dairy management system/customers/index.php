<?php

require '../includes/auth.php';
require '../config/database.php';

$customers = $pdo->query("
SELECT *
FROM customers
ORDER BY id DESC
")->fetchAll();
$search = $_GET['search'] ?? '';

$stmt = $pdo->prepare("
SELECT *
FROM customers
WHERE full_name LIKE ?
");

$stmt->execute(["%$search%"]);
$customers = $stmt->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">
    <form method="GET">
    <input type="text"
           name="search"
           value="<?= htmlspecialchars($search) ?>"
           placeholder="Search customer">
           <button class="btn btn-primary">
Search
</button>
</form>


<div class="d-flex justify-content-between">

<h2>Customers</h2>

<a href="create.php"
class="btn btn-success">

Add Customer

</a>

</div>

<br>

<table class="table table-bordered">

<thead>

<tr>

<th>ID</th>
<th>Code</th>
<th>Name</th>
<th>Phone</th>
<th>Email</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php foreach($customers as $customer): ?>

<tr>

<td><?= $customer['id'] ?></td>

<td><?= $customer['customer_code'] ?></td>

<td><?= $customer['full_name'] ?></td>

<td><?= $customer['phone'] ?></td>

<td><?= $customer['email'] ?></td>

<td>

<a href="edit.php?id=<?= $customer['id'] ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $customer['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Are you sure you want to delete this customer?')">

Delete

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>