<?php

require '../includes/auth.php';
require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
SELECT *
FROM customers
WHERE id=?
");

$stmt->execute([$id]);

$customer = $stmt->fetch();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Edit Customer</h2>

<form action="update.php" method="POST">

<input type="hidden"
       name="id"
       value="<?= $customer['id']; ?>">

<div class="mb-3">

<label>Customer Code</label>

<input type="text"
       name="customer_code"
       value="<?= $customer['customer_code']; ?>"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Full Name</label>

<input type="text"
       name="full_name"
       value="<?= $customer['full_name']; ?>"
       class="form-control"
       required>

</div>

<div class="mb-3">

<label>Phone</label>

<input type="text"
       name="phone"
       value="<?= $customer['phone']; ?>"
       class="form-control">

</div>

<div class="mb-3">

<label>Email</label>

<input type="email"
       name="email"
       value="<?= $customer['email']; ?>"
       class="form-control">

</div>

<div class="mb-3">

<label>Address</label>

<textarea name="address"
          class="form-control"><?= $customer['address']; ?></textarea>

</div>

<button class="btn btn-warning">

Update Customer

</button>

</form>

</div>

</div>