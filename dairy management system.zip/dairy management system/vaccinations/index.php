<?php

require '../includes/auth.php';
require '../config/database.php';

$totalVaccinations = $pdo->query("
SELECT COUNT(*)
FROM vaccinations
")->fetchColumn();

$dueVaccinations = $pdo->query("
SELECT COUNT(*)
FROM vaccinations
WHERE next_due_date <= CURDATE()
")->fetchColumn();

$upcomingVaccinations = $pdo->query("
SELECT COUNT(*)
FROM vaccinations
WHERE next_due_date > CURDATE()
")->fetchColumn();
$sql = "
SELECT
v.*,
c.cow_code

FROM vaccinations v

JOIN cows c
ON c.id = v.cow_id

ORDER BY v.next_due_date ASC
";

$records = $pdo->query($sql)->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';


?>
<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">
    <div class="d-flex justify-content-between mb-4">

<h2>Vaccination Records</h2>

<a href="create.php"
class="btn btn-primary">

Add Vaccination

</a>

</div>
<div class="row mb-4">

<div class="col-md-4">

<div class="card bg-primary text-white">

<div class="card-body">

<h6>Total Vaccinations</h6>

<h2><?= $totalVaccinations ?></h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-danger text-white">

<div class="card-body">

<h6>Vaccinations Due</h6>

<h2><?= $dueVaccinations ?></h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-success text-white">

<div class="card-body">

<h6>Upcoming Vaccinations</h6>

<h2><?= $upcomingVaccinations ?></h2>

</div>

</div>

</div>

</div>

<table class="table table-bordered">

<thead>

<tr>

<th>Cow</th>
<th>Vaccine</th>
<th>Date Given</th>
<th>Next Due Date</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php foreach($records as $record): ?>

<tr>

<td><?= $record['cow_code']; ?></td>

<td><?= $record['vaccine_name']; ?></td>

<td><?= $record['date_given']; ?></td>

<td><?= $record['next_due_date']; ?></td>

<td>

<a href="edit.php?id=<?= $record['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete.php?id=<?= $record['id']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete record?')">

Delete

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>