<?php

require '../config/database.php';

$stmt = $pdo->prepare("
INSERT INTO vaccinations
(
cow_id,
vaccine_name,
date_given,
next_due_date
)
VALUES
(
?,?,?,?
)
");

$stmt->execute([

$_POST['cow_id'],
$_POST['vaccine_name'],
$_POST['date_given'],
$_POST['next_due_date']

]);

header("Location:index.php");
exit();