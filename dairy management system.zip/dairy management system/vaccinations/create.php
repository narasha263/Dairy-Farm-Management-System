<?php

require '../includes/auth.php';
require '../config/database.php';

$cows = $pdo->query("
SELECT *
FROM cows
ORDER BY cow_code
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Add Vaccination Record</h2>

<form action="store.php" method="POST">

<div class="mb-3">

<label>Cow</label>

<select name="cow_id"
class="form-control"
required>

<?php foreach($cows as $cow): ?>

<option value="<?= $cow['id']; ?>">

<?= $cow['cow_code']; ?>

</option>

<?php endforeach; ?>

</select>

</div>

<div class="mb-3">

<label>Vaccine Name</label>

<input type="text"
name="vaccine_name"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Date Given</label>

<input type="date"
name="date_given"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Next Due Date</label>

<input type="date"
name="next_due_date"
class="form-control">

</div>

<button class="btn btn-primary">

Save Record

</button>

</form>

</div>

</div>