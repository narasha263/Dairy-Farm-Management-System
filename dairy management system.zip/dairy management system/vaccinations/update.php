<?php

require '../config/database.php';

$stmt = $pdo->prepare("
UPDATE vaccinations
SET
cow_id=?,
vaccine_name=?,
date_given=?,
next_due_date=?
WHERE id=?
");

$stmt->execute([

$_POST['cow_id'],
$_POST['vaccine_name'],
$_POST['date_given'],
$_POST['next_due_date'],
$_POST['id']

]);

header("Location:index.php");
exit();