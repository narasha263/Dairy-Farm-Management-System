<?php

require '../includes/auth.php';
require '../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("
SELECT *
FROM vaccinations
WHERE id=?
");

$stmt->execute([$id]);

$record = $stmt->fetch();

$cows = $pdo->query("
SELECT *
FROM cows
ORDER BY cow_code
")->fetchAll();

include '../includes/header.php';
include '../includes/sidebar.php';

?>
<form action="update.php" method="POST">

<input type="hidden"
name="id"
value="<?= $record['id']; ?>">

<select name="cow_id"
class="form-control">

<?php foreach($cows as $cow): ?>

<option
value="<?= $cow['id']; ?>"
<?= $cow['id']==$record['cow_id']
? 'selected'
: '' ?>>

<?= $cow['cow_code']; ?>

</option>

<?php endforeach; ?>

</select>

<br>

<input type="text"
name="vaccine_name"
value="<?= $record['vaccine_name']; ?>"
class="form-control">

<br>

<input type="date"
name="date_given"
value="<?= $record['date_given']; ?>"
class="form-control">

<br>

<input type="date"
name="next_due_date"
value="<?= $record['next_due_date']; ?>"
class="form-control">

<br>

<button class="btn btn-warning">

Update Record

</button>

</form>