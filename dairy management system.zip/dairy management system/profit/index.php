<?php

require '../includes/auth.php';
require '../config/database.php';

$totalRevenue = $pdo->query("
SELECT COALESCE(
SUM(total_amount),
0
)
FROM sales
")->fetchColumn();

$totalExpenses = $pdo->query("
SELECT COALESCE(
SUM(amount),
0
)
FROM expenses
")->fetchColumn();

$totalProfit =
$totalRevenue -
$totalExpenses;

include '../includes/header.php';
include '../includes/sidebar.php';

?>

<div class="main-content">

<?php include '../includes/navbar.php'; ?>

<div class="content">

<h2>Profit Analysis</h2>

<div class="row">

<div class="col-md-4">

<div class="card bg-success text-white">

<div class="card-body">

<h5>Total Revenue</h5>

<h2>
KES <?= number_format($totalRevenue,2) ?>
</h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-danger text-white">

<div class="card-body">

<h5>Total Expenses</h5>

<h2>
KES <?= number_format($totalExpenses,2) ?>
</h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-primary text-white">

<div class="card-body">

<h5>Net Profit</h5>

<h2>
KES <?= number_format($totalProfit,2) ?>
</h2>

</div>

</div>

</div>

</div>

</div>

</div>